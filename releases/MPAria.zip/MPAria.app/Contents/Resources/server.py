#!/usr/bin/env python3
"""Tiny local web server for MPAria.

Running the player over http://127.0.0.1 gives the browser a proper origin for
IndexedDB and service workers, so imports survive restarts and the app works
offline. The server shuts itself down after a long period without requests.
"""
import http.server
import json
import re
import os
import socket
import sys
import tempfile
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from functools import partial
from pathlib import Path

IDLE_SECONDS = 12 * 60 * 60
PREFERRED_PORT = 47113
PORT_ATTEMPTS = 10
MAX_DOWNLOAD_BYTES = 300 * 1024 * 1024


def fetch_remote_audio(url):
    """Download a user-supplied audio URL on behalf of the page.

    Browsers block cross-origin downloads unless the remote server sends CORS
    headers, so the local server relays the request. It only accepts http(s)
    links and caps the response size to protect the machine.
    """
    parsed = urllib.parse.urlparse(url)
    if parsed.scheme not in ("http", "https") or not parsed.netloc:
        raise ValueError("Only http:// and https:// links are supported.")

    request = urllib.request.Request(
        url,
        headers={
            "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X) MPAria/1.0",
            "Accept": "audio/*,application/octet-stream,*/*;q=0.8",
        },
    )
    with urllib.request.urlopen(request, timeout=45) as remote:
        content_type = remote.headers.get("Content-Type", "application/octet-stream")
        declared = remote.headers.get("Content-Length")
        if declared:
            try:
                declared_size = int(declared)
            except (TypeError, ValueError):
                declared_size = 0
            if declared_size > MAX_DOWNLOAD_BYTES:
                raise ValueError("That file is larger than the 300 MB import limit.")
        chunks = []
        total = 0
        while True:
            chunk = remote.read(64 * 1024)
            if not chunk:
                break
            total += len(chunk)
            if total > MAX_DOWNLOAD_BYTES:
                raise ValueError("That file is larger than the 300 MB import limit.")
            chunks.append(chunk)
        return b"".join(chunks), content_type


def fetch_youtube_info(url):
    parsed = urllib.parse.urlparse(url)
    query = urllib.parse.parse_qs(parsed.query)
    video_id = query.get("v", [None])[0]
    if not video_id and "youtu.be" in (parsed.netloc or ""):
        video_id = (parsed.path or "").strip("/").split("/")[0]
    if not video_id:
        raise ValueError("Could not find a YouTube video ID.")

    thumbnail = "https://i.ytimg.com/vi/%s/hqdefault.jpg" % video_id
    title = "YouTube video"
    author = "YouTube"
    duration = 0

    # Try the watch page with a browser-like user agent. This exposes
    # ytInitialPlayerResponse, including lengthSeconds and thumbnail.
    try:
        watch_url = "https://www.youtube.com/watch?v=" + urllib.parse.quote(video_id)
        request = urllib.request.Request(
            watch_url,
            headers={
                "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
                "Accept-Language": "en-US,en;q=0.9",
            },
        )
        with urllib.request.urlopen(request, timeout=20) as remote:
            html = remote.read().decode("utf-8", errors="replace")
        idx = html.find("ytInitialPlayerResponse")
        if idx != -1:
            start = html.find("{", idx)
            if start != -1:
                obj, _ = json.JSONDecoder().raw_decode(html[start:])
                video_details = obj.get("videoDetails") or {}
                title = video_details.get("title") or title
                author = video_details.get("author") or author
                try:
                    duration = int(video_details.get("lengthSeconds") or 0)
                except (TypeError, ValueError):
                    duration = 0
                thumbs = (video_details.get("thumbnail") or {}).get("thumbnails") or []
                if thumbs:
                    thumbnail = thumbs[-1].get("url") or thumbnail
    except Exception:
        pass

    # Fallback to oEmbed for title/author/thumbnail if needed.
    if title == "YouTube video" or author == "YouTube" or not thumbnail:
        try:
            oembed_url = "https://www.youtube.com/oembed?url=https://www.youtube.com/watch?v=%s&format=json" % urllib.parse.quote(video_id)
            request = urllib.request.Request(
                oembed_url,
                headers={"User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X) MPAria/1.0"},
            )
            with urllib.request.urlopen(request, timeout=20) as remote:
                data = json.loads(remote.read().decode("utf-8"))
            title = data.get("title") or title
            author = data.get("author_name") or author
            thumbnail = data.get("thumbnail_url") or thumbnail
        except Exception:
            pass

    return {
        "videoId": video_id,
        "title": title,
        "author": author,
        "duration": duration,
        "thumbnail": thumbnail,
    }

def mparia_is_running(port):
    try:
        with urllib.request.urlopen(
            "http://127.0.0.1:%d/__mparia_health" % port, timeout=0.7
        ) as response:
            data = json.loads(response.read().decode("utf-8"))
            return data.get("app") == "mparia"
    except Exception:
        return False


class Handler(http.server.SimpleHTTPRequestHandler):
    last_request = time.time()

    def do_GET(self):
        Handler.last_request = time.time()
        if self.path.startswith("/__mparia_health"):
            self._send_json(200, {"app": "mparia", "ok": True, "version": 2})
            return
        if self.path.startswith("/__mparia_youtube_info"):
            self._youtube_info()
            return
        if self.path.startswith("/__mparia_fetch"):
            self._proxy_audio()
            return
        Handler.last_request = time.time()
        super().do_GET()

    def _send_json(self, status, payload):
        body = json.dumps(payload).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def _youtube_info(self):
        query = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)
        url = (query.get("url") or [""])[0].strip()
        if not url:
            self._send_json(400, {"error": "No URL was provided."})
            return
        try:
            info = fetch_youtube_info(url)
        except ValueError as error:
            self._send_json(400, {"error": str(error)})
            return
        except Exception as error:
            self._send_json(502, {"error": "Could not read that YouTube page: %s" % error})
            return
        self._send_json(200, info)

    def _proxy_audio(self):
        if self.headers.get("X-MPAria-Download") != "1":
            self._send_json(403, {"error": "Missing download request header."})
            return
        query = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)
        url = (query.get("url") or [""])[0].strip()
        if not url:
            self._send_json(400, {"error": "No URL was provided."})
            return
        try:
            data, content_type = fetch_remote_audio(url)
        except urllib.error.HTTPError as error:
            self._send_json(502, {"error": "The remote server returned %d." % error.code})
            return
        except ValueError as error:
            self._send_json(400, {"error": str(error)})
            return
        except Exception as error:
            self._send_json(502, {"error": "Could not download that link: %s" % error})
            return

        if not data:
            self._send_json(502, {"error": "The remote file was empty."})
            return

        self.send_response(200)
        self.send_header("Content-Type", content_type or "application/octet-stream")
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(data)

    def end_headers(self):
        if self.path.endswith(("sw.js", "index.html", "/")):
            self.send_header("Cache-Control", "no-cache")
        self.send_header("X-Content-Type-Options", "nosniff")
        super().end_headers()

    def log_message(self, fmt, *args):
        try:
            with open(Path(tempfile.gettempdir()) / "mparia-server.log", "a", encoding="utf-8") as log:
                log.write("%s - %s\n" % (self.address_string(), fmt % args))
        except OSError:
            pass


def idle_watchdog(server):
    while True:
        time.sleep(60)
        if time.time() - Handler.last_request > IDLE_SECONDS:
            try:
                server.shutdown()
            except Exception:
                pass
            return


def main():
    root = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else Path(__file__).resolve().parents[2]
    if not (root / "index.html").exists():
        print("MPAria: index.html not found in", root, file=sys.stderr)
        return 1

    port_file = Path(tempfile.gettempdir()) / "mparia-player-port"

    class Server(http.server.ThreadingHTTPServer):
        daemon_threads = True
        allow_reuse_address = True

    handler = partial(Handler, directory=str(root))
    httpd = None
    port = PREFERRED_PORT
    for offset in range(PORT_ATTEMPTS):
        candidate = PREFERRED_PORT + offset
        try:
            httpd = Server(("127.0.0.1", candidate), handler)
            port = candidate
            break
        except OSError:
            # The same app may already be serving; keep the original origin so
            # its IndexedDB library stays available.
            if mparia_is_running(candidate):
                try:
                    port_file.write_text(str(candidate), encoding="utf-8")
                except OSError:
                    pass
                print("MPAria is already running at http://127.0.0.1:%d/" % candidate, flush=True)
                return 0
            continue

    if httpd is None:
        print("MPAria: no free local port was available.", file=sys.stderr)
        return 1

    with httpd:
        Handler.last_request = time.time()
        try:
            port_file.write_text(str(port), encoding="utf-8")
        except OSError:
            pass
        print("MPAria is serving", root, "at http://127.0.0.1:%d/" % port, flush=True)
        threading.Thread(target=idle_watchdog, args=(httpd,), daemon=True).start()
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            pass
        finally:
            try:
                if port_file.exists() and port_file.read_text(encoding="utf-8").strip() == str(port):
                    port_file.unlink()
            except OSError:
                pass
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
