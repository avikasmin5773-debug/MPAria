#!/bin/bash
# Rebuilds the native MPAria shell. Run after editing main.swift:
#
#   bash "/Users/sara/MP3player.app/Contents/Resources/build-app.sh"
#
set -euo pipefail

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
RES="$DIR/Contents/Resources"
OUT="$DIR/Contents/MacOS/launcher"

if ! command -v swiftc >/dev/null 2>&1; then
  echo "swiftc not found. Install the Xcode command line tools: xcode-select --install" >&2
  exit 1
fi

echo "Compiling native shell..."
swiftc -O -o "$OUT" "$RES/main.swift" -framework Cocoa -framework WebKit
chmod +x "$OUT"

# Refresh the Finder/Dock icon if a source SVG is available.
ICON_SRC="$DIR/assets/icon.svg"
if [ -f "$ICON_SRC" ] && command -v qlmanage >/dev/null 2>&1 && command -v iconutil >/dev/null 2>&1; then
  WORK="$(mktemp -d)"
  if sips -s format png "$ICON_SRC" --out "$WORK/icon.svg.png" >/dev/null 2>&1 && [ -f "$WORK/icon.svg.png" ]; then
    sips -z 1024 1024 "$WORK/icon.svg.png" --out "$WORK/icon.svg.png" >/dev/null 2>&1 || true
    mkdir -p "$WORK/AppIcon.iconset"
    for size in 16 32 128 256 512; do
      sips -z "$size" "$size" "$WORK/icon.svg.png" \
        --out "$WORK/AppIcon.iconset/icon_${size}x${size}.png" >/dev/null
      sips -z "$((size * 2))" "$((size * 2))" "$WORK/icon.svg.png" \
        --out "$WORK/AppIcon.iconset/icon_${size}x${size}@2x.png" >/dev/null
    done
    iconutil -c icns "$WORK/AppIcon.iconset" -o "$RES/AppIcon.icns"
    echo "Updated Contents/Resources/AppIcon.icns"
  fi
  rm -rf "$WORK"
fi

# Make sure macOS is willing to launch the modified bundle.
xattr -cr "$DIR" 2>/dev/null || true
/System/Library/Frameworks/CoreServices.framework/Frameworks/LaunchServices.framework/Support/lsregister -f "$DIR" 2>/dev/null || true

echo "Built $OUT"
