# Sourced by /bin/bash when macOS launches this app bundle.
# It hands control to the real launcher without needing a custom executable bit.
if [ -z "${MPARIA_BOOTSTRAPPED:-}" ]; then
  export MPARIA_BOOTSTRAPPED=1
  exec /bin/bash "/Users/abi/Desktop/MP3player.app/Contents/MacOS/launcher"
fi
