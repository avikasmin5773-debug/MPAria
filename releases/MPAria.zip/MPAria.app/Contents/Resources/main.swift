// MPAria — native macOS shell.
//
// The player itself is the web app in the bundle root (index.html, css/, js/).
// This shell runs that app in a real WKWebView window with its own dock icon,
// so it behaves like a normal macOS application instead of a browser tab. The
// small Python helper (server.py) still serves the files on http://127.0.0.1
// so IndexedDB and the service worker get a stable origin and the library
// survives between launches.

import Cocoa
@preconcurrency import WebKit

// MARK: - Local file server

enum ServerError: LocalizedError {
    case pythonMissing
    case didNotStart

    var errorDescription: String? {
        switch self {
        case .pythonMissing:
            return "MPAria could not find Python 3, which it uses to serve the local library."
        case .didNotStart:
            return "MPAria could not start its local library server."
        }
    }

    var recoverySuggestion: String? {
        switch self {
        case .pythonMissing:
            return "Install Python 3 (for example from python.org or Homebrew) and open MPAria again."
        case .didNotStart:
            return "Quit any other copy of MPAria and try again. If it keeps happening, check /tmp/mparia-server.log."
        }
    }
}

final class LocalServer {
    private var process: Process?
    private let root: URL
    private let portFile: URL

    init(root: URL) {
        self.root = root
        self.portFile = URL(fileURLWithPath: NSTemporaryDirectory())
            .appendingPathComponent("mparia-player-port")
    }

    private static func pythonPath() -> URL? {
        let candidates = [
            "/opt/homebrew/bin/python3",
            "/usr/local/bin/python3",
            "/usr/bin/python3",
            "/Library/Frameworks/Python.framework/Versions/Current/bin/python3",
        ]
        for path in candidates where FileManager.default.isExecutableFile(atPath: path) {
            return URL(fileURLWithPath: path)
        }
        return nil
    }

    /// Starts server.py if it is not already serving, then returns its port.
    func start() throws -> Int {
        if let port = readPort(), isMPAria(port) {
            return port
        }
        try? FileManager.default.removeItem(at: portFile)

        guard let python = LocalServer.pythonPath() else {
            throw ServerError.pythonMissing
        }

        let task = Process()
        task.executableURL = python
        task.arguments = [
            root.appendingPathComponent("Contents/Resources/server.py").path,
            root.path,
        ]
        task.currentDirectoryURL = root

        let logURL = URL(fileURLWithPath: NSTemporaryDirectory())
            .appendingPathComponent("mparia-server.log")
        if !FileManager.default.fileExists(atPath: logURL.path) {
            FileManager.default.createFile(atPath: logURL.path, contents: nil)
        }
        if let log = try? FileHandle(forWritingTo: logURL) {
            log.seekToEndOfFile()
            task.standardOutput = log
            task.standardError = log
        }

        try task.run()
        process = task

        // Wait for server.py to bind a port and write it out.
        let deadline = Date().addingTimeInterval(8)
        while Date() < deadline {
            if let port = readPort() {
                return port
            }
            if !task.isRunning {
                // It may have exited because another copy already serves the app.
                if let port = readPort() {
                    return port
                }
                break
            }
            Thread.sleep(forTimeInterval: 0.08)
        }

        if let port = readPort() {
            return port
        }
        throw ServerError.didNotStart
    }

    func stop() {
        process?.terminate()
        process = nil
    }

    private func readPort() -> Int? {
        guard let text = try? String(contentsOf: portFile, encoding: .utf8) else {
            return nil
        }
        let trimmed = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard let port = Int(trimmed), port > 0, port < 65536 else {
            return nil
        }
        return port
    }

    private func isMPAria(_ port: Int) -> Bool {
        guard let url = URL(string: "http://127.0.0.1:\(port)/__mparia_health") else {
            return false
        }
        var request = URLRequest(url: url)
        request.timeoutInterval = 1
        request.cachePolicy = .reloadIgnoringLocalCacheData
        let semaphore = DispatchSemaphore(value: 0)
        var healthy = false
        URLSession.shared.dataTask(with: request) { data, _, _ in
            if let data, let body = String(data: data, encoding: .utf8) {
                healthy = body.contains("mparia")
            }
            semaphore.signal()
        }.resume()
        _ = semaphore.wait(timeout: .now() + 1.5)
        return healthy
    }
}

// MARK: - Application

final class AppDelegate: NSObject, NSApplicationDelegate, WKNavigationDelegate, WKUIDelegate {
    private var window: NSWindow!
    private var webView: WKWebView!
    private var server: LocalServer?
    private var baseURL: URL?

    func applicationDidFinishLaunching(_ notification: Notification) {
        buildMenu()

        let root = Bundle.main.bundleURL
        let server = LocalServer(root: root)
        self.server = server

        do {
            let port = try server.start()
            guard let url = URL(string: "http://127.0.0.1:\(port)/index.html") else {
                throw ServerError.didNotStart
            }
            baseURL = url
            createWindow()
            webView.load(URLRequest(url: url))
        } catch {
            presentFatalError(error)
        }
    }

    func applicationShouldTerminateAfterLastWindowClosed(_ sender: NSApplication) -> Bool {
        true
    }

    func applicationWillTerminate(_ notification: Notification) {
        server?.stop()
    }

    // MARK: Window

    private func createWindow() {
        let configuration = WKWebViewConfiguration()
        configuration.websiteDataStore = .default()
        configuration.mediaTypesRequiringUserActionForPlayback = []
        configuration.preferences.isElementFullscreenEnabled = true
        configuration.defaultWebpagePreferences.allowsContentJavaScript = true

        webView = WKWebView(frame: .zero, configuration: configuration)
        webView.navigationDelegate = self
        webView.uiDelegate = self
        webView.allowsMagnification = true

        let frame = NSRect(x: 0, y: 0, width: 1240, height: 800)
        window = NSWindow(
            contentRect: frame,
            styleMask: [.titled, .closable, .miniaturizable, .resizable],
            backing: .buffered,
            defer: false
        )
        window.title = "MPAria"
        window.minSize = NSSize(width: 900, height: 560)
        window.backgroundColor = NSColor(calibratedRed: 0, green: 0, blue: 0, alpha: 1)
        window.contentView = webView
        window.setFrameAutosaveName("MPAriaMainWindow")
        window.center()
        window.makeKeyAndOrderFront(nil)
        NSApp.activate(ignoringOtherApps: true)
    }

    private func presentFatalError(_ error: Error) {
        let alert = NSAlert()
        alert.alertStyle = .critical
        alert.messageText = "MPAria could not start"
        alert.informativeText = [error.localizedDescription,
                                 (error as? LocalizedError)?.recoverySuggestion]
            .compactMap { $0 }
            .joined(separator: "\n\n")
        alert.addButton(withTitle: "Quit")
        alert.runModal()
        NSApp.terminate(nil)
    }

    // MARK: Navigation

    func webView(_ webView: WKWebView,
                 decidePolicyFor navigationAction: WKNavigationAction,
                 decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        guard let url = navigationAction.request.url else {
            decisionHandler(.allow)
            return
        }

        let isLocal = url.host == "127.0.0.1" || url.host == "localhost"
        if isLocal {
            decisionHandler(.allow)
            return
        }

        // Anything else belongs in the user's browser, not inside the app.
        if navigationAction.navigationType == .linkActivated || url.scheme == "http" || url.scheme == "https" {
            NSWorkspace.shared.open(url)
            decisionHandler(.cancel)
            return
        }

        decisionHandler(.allow)
    }

    func webView(_ webView: WKWebView,
                 createWebViewWith configuration: WKWebViewConfiguration,
                 for navigationAction: WKNavigationAction,
                 windowFeatures: WKWindowFeatures) -> WKWebView? {
        if let url = navigationAction.request.url, url.scheme == "http" || url.scheme == "https" {
            NSWorkspace.shared.open(url)
        }
        return nil
    }

    // MARK: JavaScript dialogs

    func webView(_ webView: WKWebView,
                 runJavaScriptAlertPanelWithMessage message: String,
                 initiatedByFrame frame: WKFrameInfo,
                 completionHandler: @escaping () -> Void) {
        let alert = NSAlert()
        alert.messageText = message
        alert.addButton(withTitle: "OK")
        finish(alert, for: webView, completionHandler: completionHandler)
    }

    func webView(_ webView: WKWebView,
                 runJavaScriptConfirmPanelWithMessage message: String,
                 initiatedByFrame frame: WKFrameInfo,
                 completionHandler: @escaping (Bool) -> Void) {
        let alert = NSAlert()
        alert.messageText = message
        alert.addButton(withTitle: "OK")
        alert.addButton(withTitle: "Cancel")
        if let window = webView.window {
            alert.beginSheetModal(for: window) { response in
                completionHandler(response == .alertFirstButtonReturn)
            }
        } else {
            completionHandler(alert.runModal() == .alertFirstButtonReturn)
        }
    }

    private func finish(_ alert: NSAlert, for webView: WKWebView, completionHandler: @escaping () -> Void) {
        if let window = webView.window {
            alert.beginSheetModal(for: window) { _ in completionHandler() }
        } else {
            alert.runModal()
            completionHandler()
        }
    }

    // MARK: Menu

    private func buildMenu() {
        let mainMenu = NSMenu()

        let appMenuItem = NSMenuItem()
        let appMenu = NSMenu()
        appMenu.addItem(withTitle: "About MPAria",
                        action: #selector(NSApplication.orderFrontStandardAboutPanel(_:)),
                        keyEquivalent: "")
        appMenu.addItem(.separator())
        appMenu.addItem(withTitle: "Hide MPAria", action: #selector(NSApplication.hide(_:)), keyEquivalent: "h")
        let hideOthers = appMenu.addItem(withTitle: "Hide Others",
                                         action: #selector(NSApplication.hideOtherApplications(_:)),
                                         keyEquivalent: "h")
        hideOthers.keyEquivalentModifierMask = [.command, .option]
        appMenu.addItem(withTitle: "Show All", action: #selector(NSApplication.unhideAllApplications(_:)), keyEquivalent: "")
        appMenu.addItem(.separator())
        appMenu.addItem(withTitle: "Quit MPAria", action: #selector(NSApplication.terminate(_:)), keyEquivalent: "q")
        appMenuItem.submenu = appMenu
        mainMenu.addItem(appMenuItem)

        let editMenuItem = NSMenuItem()
        let editMenu = NSMenu(title: "Edit")
        editMenu.addItem(withTitle: "Undo", action: Selector(("undo:")), keyEquivalent: "z")
        let redo = editMenu.addItem(withTitle: "Redo", action: Selector(("redo:")), keyEquivalent: "z")
        redo.keyEquivalentModifierMask = [.command, .shift]
        editMenu.addItem(.separator())
        editMenu.addItem(withTitle: "Cut", action: #selector(NSText.cut(_:)), keyEquivalent: "x")
        editMenu.addItem(withTitle: "Copy", action: #selector(NSText.copy(_:)), keyEquivalent: "c")
        editMenu.addItem(withTitle: "Paste", action: #selector(NSText.paste(_:)), keyEquivalent: "v")
        editMenu.addItem(withTitle: "Select All", action: #selector(NSText.selectAll(_:)), keyEquivalent: "a")
        editMenuItem.submenu = editMenu
        mainMenu.addItem(editMenuItem)

        let viewMenuItem = NSMenuItem()
        let viewMenu = NSMenu(title: "View")
        viewMenu.addItem(withTitle: "Reload", action: #selector(reloadPage), keyEquivalent: "r")
        viewMenu.addItem(withTitle: "Actual Size", action: #selector(actualSize), keyEquivalent: "0")
        viewMenu.addItem(withTitle: "Zoom In", action: #selector(zoomIn), keyEquivalent: "+")
        viewMenu.addItem(withTitle: "Zoom Out", action: #selector(zoomOut), keyEquivalent: "-")
        viewMenu.addItem(.separator())
        viewMenu.addItem(withTitle: "Enter Full Screen",
                         action: #selector(NSWindow.toggleFullScreen(_:)),
                         keyEquivalent: "f")
        viewMenuItem.submenu = viewMenu
        mainMenu.addItem(viewMenuItem)

        let windowMenuItem = NSMenuItem()
        let windowMenu = NSMenu(title: "Window")
        windowMenu.addItem(withTitle: "Minimize", action: #selector(NSWindow.performMiniaturize(_:)), keyEquivalent: "m")
        windowMenu.addItem(withTitle: "Zoom", action: #selector(NSWindow.performZoom(_:)), keyEquivalent: "")
        windowMenu.addItem(.separator())
        windowMenu.addItem(withTitle: "Bring All to Front",
                           action: #selector(NSApplication.arrangeInFront(_:)),
                           keyEquivalent: "")
        windowMenuItem.submenu = windowMenu
        mainMenu.addItem(windowMenuItem)

        NSApp.mainMenu = mainMenu
        NSApp.windowsMenu = windowMenu
    }

    @objc private func reloadPage() {
        webView.reload()
    }

    @objc private func actualSize() {
        webView.pageZoom = 1
    }

    @objc private func zoomIn() {
        webView.pageZoom = min(webView.pageZoom + 0.1, 3)
    }

    @objc private func zoomOut() {
        webView.pageZoom = max(webView.pageZoom - 0.1, 0.5)
    }
}

// MARK: - Entry point

let application = NSApplication.shared
let delegate = AppDelegate()
application.delegate = delegate
application.setActivationPolicy(.regular)
application.run()
